NEXT 2.2 Android wrapper
- Local app served to WebView from secure https://next.local origin.
- GPS permission bridged to Android.
- “Condividi richiesta” sends the generated .nextreq.json through Android share sheet.
- ACTION_VIEW / ACTION_SEND receives JSON/.nextplan files; only NEXT_PLAN_V2 payloads are imported.
- NEXT 2.1 logic is preserved; APK-specific bridge added.
Build target: Android 15 / API 35, min Android 8 / API 26.
