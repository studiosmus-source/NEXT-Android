package com.next.travel;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.util.Base64;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private String pendingJson, pendingName;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER=88;
    private static final String APP_ORIGIN="https://next.local/";

    @Override protected void onCreate(Bundle b){ super.onCreate(b); setupWeb(); handleIntent(getIntent()); }
    @Override protected void onNewIntent(Intent i){ super.onNewIntent(i); setIntent(i); handleIntent(i); }

    private void setupWeb(){
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(),"AndroidBridge");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb){
                if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) cb.invoke(origin,true,false);
                else { requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},77); cb.invoke(origin,false,false); }
            }
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(filePathCallback!=null) filePathCallback.onReceiveValue(null);
                filePathCallback=callback;
                Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                try{ startActivityForResult(pick,FILE_CHOOSER); return true; }
                catch(Exception e){ filePathCallback=null; return false; }
            }
        });
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
                Uri u=r.getUrl(); if(!"next.local".equals(u.getHost())) return null;
                String path=u.getPath(); if(path==null||path.equals("/")||path.equals("/index.html")) path="/index.html";
                try{ InputStream in=getAssets().open(path.substring(1)); return new WebResourceResponse(mime(path),"UTF-8",in); }
                catch(Exception e){ return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",null,new ByteArrayInputStream(new byte[0])); }
            }
            @Override public void onPageFinished(WebView v,String url){ deliverPending(); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
                Uri u=r.getUrl(); if("next.local".equals(u.getHost())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW,u)); return true;
            }
        });
        web.loadUrl(APP_ORIGIN+"index.html");
    }

    private static String mime(String p){ if(p.endsWith(".html"))return "text/html"; if(p.endsWith(".js"))return "application/javascript"; if(p.endsWith(".css"))return "text/css"; if(p.endsWith(".json")||p.endsWith(".webmanifest"))return "application/json"; if(p.endsWith(".png"))return "image/png"; return "application/octet-stream"; }

    private void handleIntent(Intent i){
        if(i==null)return; Uri uri=null;
        if(Intent.ACTION_VIEW.equals(i.getAction())) uri=i.getData();
        else if(Intent.ACTION_SEND.equals(i.getAction())) uri=(Uri)i.getParcelableExtra(Intent.EXTRA_STREAM);
        if(uri==null)return;
        try{
            String txt; try(InputStream in=getContentResolver().openInputStream(uri)){ txt=new String(readAll(in), StandardCharsets.UTF_8); }
            if(!txt.contains("\"schema\"") || !txt.contains("NEXT_PLAN_V2")) return;
            pendingJson=txt; pendingName=fileName(uri); deliverPending();
        }catch(Exception ignored){}
    }

    private String fileName(Uri uri){
        String n="NEXT_received.nextplan";
        try(android.database.Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null && c.moveToFirst()){ String x=c.getString(0); if(x!=null&&!x.isBlank())n=x; }
        }catch(Exception ignored){}
        return n;
    }

    private void deliverPending(){
        if(web==null||pendingJson==null)return;
        String b64=Base64.encodeToString(pendingJson.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
        String n64=Base64.encodeToString(pendingName.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
        String js="(function(){if(window.NEXT_ANDROID_IMPORT){const d=new TextDecoder().decode(Uint8Array.from(atob('"+b64+"'),c=>c.charCodeAt(0)));const n=new TextDecoder().decode(Uint8Array.from(atob('"+n64+"'),c=>c.charCodeAt(0)));window.NEXT_ANDROID_IMPORT(d,n);return true;}return false;})()";
        web.evaluateJavascript(js,val->{ if("true".equals(val)){pendingJson=null; pendingName=null;} });
    }


    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[8192]; int n;
        while((n=in.read(buf))!=-1) out.write(buf,0,n);
        return out.toByteArray();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=FILE_CHOOSER || filePathCallback==null)return;
        Uri[] result=WebChromeClient.FileChooserParams.parseResult(resultCode,data);
        filePathCallback.onReceiveValue(result);
        filePathCallback=null;
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){ super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==77 && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) web.reload(); }

    public class Bridge {
        @JavascriptInterface public void shareRequest(String fileName,String json){ runOnUiThread(()->{
            try{
                String safe=fileName==null?"NEXT_request.nextreq.json":fileName.replaceAll("[^A-Za-z0-9._-]","_");
                File dir=new File(getCacheDir(),"shared"); dir.mkdirs(); File f=new File(dir,safe);
                try(FileOutputStream o=new FileOutputStream(f)){o.write(json.getBytes(StandardCharsets.UTF_8));}
                Uri u=Uri.parse("content://com.next.travel.files/shared/"+Uri.encode(safe));
                Intent sh=new Intent(Intent.ACTION_SEND); sh.setType("application/json"); sh.putExtra(Intent.EXTRA_STREAM,u); sh.putExtra(Intent.EXTRA_SUBJECT,"Richiesta viaggio NEXT");
                sh.putExtra(Intent.EXTRA_TEXT,"Crea il piano NEXT da questo file e restituiscimi un file .nextplan scaricabile.");
                sh.setClipData(ClipData.newRawUri(safe,u)); sh.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try{
                    Intent chatgpt=new Intent(sh);
                    chatgpt.setPackage("com.openai.chatgpt");
                    startActivity(chatgpt);
                }catch(Exception noChatGpt){
                    startActivity(Intent.createChooser(sh,"Invia richiesta NEXT"));
                }
            }catch(Exception ignored){}
        }); }
    }
}
