NEXT 2.4 Android — ASSISTANT BUILD

Core Android
- WebView su origine interna sicura https://next.local
- GPS Android
- Invio .nextreq direttamente a ChatGPT (fallback chooser)
- Apertura/import automatico dei file NEXT_PLAN_V2 ricevuti da Android
- Tema chiaro/scuro automatico secondo il sistema, inclusi status/navigation bar
- TTS Android per un solo avviso vocale critico durante la guida

Mobilità
- Auto + piedi: il limite di cammino sceglie il mezzo, non taglia il mondo visitabile
- Confronto tempi pedonali / auto
- Ricerca parcheggi OSM vicino alla tappa o al cluster di tappe
- Cluster di visita: più tappe vicine possono condividere lo stesso parcheggio
- Ritorno all'auto gestito quando l'auto è parcheggiata lontano dalla tappa successiva
- Stanco / Fame / Ritardo influenzano davvero la scelta del mezzo

Modalità Viaggio / Assistente
- Pulsante INIZIA VIAGGIO dal Piano
- Home contestuale: prossima tappa, mezzo, ETA, parcheggio, tratto a piedi, tappa successiva
- Stato visita con tempo trascorso e residuo previsto
- Stima multimodale prudenziale verso il prossimo HARD (buffer parcheggio; niente traffico inventato)
- Modalità Guida automatica da velocità GPS: interfaccia ridotta, niente popup/vibrazioni/notifiche
- Uscita automatica dalla modalità guida dopo circa 45 s fermi
- “Sono passeggero” sblocca l'interfaccia mentre l'auto si muove
- In guida: un solo avviso vocale per HARD entro 20 min, se TTS disponibile
- Navigazione affidata a Google Maps

APK cleanup
- Rimossi dal flusso APK installazione PWA, manifest/service worker e download HTML

Limiti dichiarati
- Parcheggi: dati OSM, disponibilità e costo reali da verificare
- Tempi auto: routing, non traffico live
- La stima HARD usa un buffer prudenziale per i tratti auto e non sostituisce un navigatore con traffico live

Build target: Android 15 / API 35, min Android 8 / API 26.
